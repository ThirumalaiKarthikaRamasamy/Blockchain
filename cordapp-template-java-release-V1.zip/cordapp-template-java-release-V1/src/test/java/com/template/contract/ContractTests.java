package com.template.contract;

import org.junit.Test;

public class ContractTests {
    @Test
    public void transactionMustIncludeCreateCommand() {

    }
}