package com.template.state;

import com.google.common.collect.ImmutableList;
import com.template.contract.IOUContract;
import net.corda.core.contracts.ContractState;
import net.corda.core.identity.AbstractParty;

import java.util.List;
import com.template.model.IOU;
import net.corda.core.identity.Party;
import org.jetbrains.annotations.NotNull;

/**
 * Define your state object here.
 */
public class IOUState implements ContractState {

    private final IOU iou;
    private IOUContract contract;
    private final Party lender;
    private final Party borrower;



    public IOU getIou() {
        return iou;
    }

      public IOUState(IOU iou, Party lender, Party borrower) {
        this.iou = iou;
        this.lender = lender;
        this.borrower = borrower;
    }

    @NotNull
    @Override
    public IOUContract getContract() {
        return contract;
    }

    public Party getLender() {
        return lender;
    }

    public Party getBorrower() {
        return borrower;
    }

    /** The public keys of the involved parties. */
    @Override public List<AbstractParty> getParticipants() { return ImmutableList.of(lender,borrower); }
}