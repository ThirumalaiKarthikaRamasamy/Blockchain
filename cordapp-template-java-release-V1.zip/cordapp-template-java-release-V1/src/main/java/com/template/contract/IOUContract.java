package com.template.contract;

import com.template.state.IOUState;
import net.corda.core.contracts.AuthenticatedObject;
import net.corda.core.contracts.Contract;
import net.corda.core.contracts.CommandData;
//import net.corda.core.contracts.CommandWithParties;
import net.corda.core.crypto.SecureHash;
import net.corda.core.identity.Party;
import net.corda.core.transactions.LedgerTransaction;
import static net.corda.core.contracts.ContractsDSL.requireThat;
import static net.corda.core.contracts.ContractsDSL.requireSingleCommand;

/**
 * Define your contract here.
 */
public class IOUContract implements Contract {
    // Used to identify this contract for use in a transaction
    public static final String TEMPLATE_CONTRACT_ID = "com.template.contract.IOUContract";

    /**
     * The verify() function of the contract of each of the transaction's input and output states must not throw an
     * exception for a transaction to be considered valid.
     */
    @Override
    public void verify(LedgerTransaction tx) {
        final AuthenticatedObject<Create> command = requireSingleCommand(tx.getCommands(), Create.class);
        requireThat(check -> {
            check.using("No input should be consume when issuing an IOU",tx.getInputs().isEmpty());
            check.using("Only one output state should be created",tx.getOutputs().size()==1);

            final IOUState out = (IOUState) tx.getOutputStates().get(0);
            final Party sender = out.getLender();
            final Party reciever = out.getBorrower();

            check.using("The IOU's value must be non negative",out.getIou().getValue()>0);
            check.using("The sener and reciever cannot be same entity",out.getLender()!= out.getBorrower());

           return null;
        });

     }

    private final SecureHash legalContractReference = SecureHash.sha256("Prose contract.");

    @Override
    public final SecureHash getLegalContractReference(){
        return legalContractReference;
    }

    // Our Create command.
    public static class Create implements CommandData {
       /* private final Integer val;
        private final String data;

        public Integer getVal() {
            return val;
        }

        public String getData() {
            return data;
        }

        public Create(Integer val, String data) {
            this.val = val;
            this.data = data;
        }*/
    }



    }