package com.template.model;

public class IOU  {
    private final Integer value;

    public Integer getValue() {
        return value;
    }

    public IOU(Integer value) {
        this.value = value;
    }
}
